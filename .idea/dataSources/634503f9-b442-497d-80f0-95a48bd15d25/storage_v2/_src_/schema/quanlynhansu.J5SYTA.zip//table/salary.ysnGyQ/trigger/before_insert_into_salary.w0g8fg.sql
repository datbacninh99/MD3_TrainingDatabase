create definer = root@localhost trigger before_insert_into_salary
    before insert
    on salary
    for each row
begin
    declare baseSalary float ;
    select BasicSalary into  baseSalary from Levels l join Employee e
                                                           on l.Id = e.levelId where e.Id = NEW.employeeId;
    set NEW.Insurrance = 0.1*baseSalary;
end;

