create definer = root@localhost view v_getemployeeinfo as
select `e`.`Id`                                                               AS `Id`,
       `e`.`Name`                                                             AS `Name`,
       `e`.`email`                                                            AS `Email`,
       `e`.`phone`                                                            AS `Phone`,
       `e`.`address`                                                          AS `Address`,
       (case `e`.`gender` when 0 then 'Nam' when 1 then 'Nữ' else 'LGBT' end) AS `gen`,
       `e`.`birthday`                                                         AS `BirthDay`,
       `d`.`Name`                                                             AS `DepartmentName`,
       `l`.`Name`                                                             AS `levelName`
from ((`quanlynhansu`.`employee` `e` join `quanlynhansu`.`department` `d`
       on ((`e`.`departmentId` = `d`.`Id`))) join `quanlynhansu`.`levels` `l` on ((`e`.`levelId` = `l`.`Id`)));

