create
    definer = root@localhost procedure getEmployeePaginate(IN page int, IN size int)
begin
    declare off_set int ;
    set off_set = page*size;
    select Id, Name, Email,Phone, Address, Gender, BirthDay
    from employee limit off_set,size;
end;

