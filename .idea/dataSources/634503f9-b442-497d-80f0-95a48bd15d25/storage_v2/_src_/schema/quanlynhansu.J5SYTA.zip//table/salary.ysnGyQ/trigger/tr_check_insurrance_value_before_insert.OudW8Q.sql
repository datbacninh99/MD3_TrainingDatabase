create definer = root@localhost trigger tr_Check_Insurrance_value_before_insert
    before insert
    on salary
    for each row
begin
    declare baseSalary float;
    select BasicSalary into baseSalary
    from levels l join  employee e on l.Id = e.levelId
    where e.Id = NEW.employeeId;
    if baseSalary*0.1 <> NEW.Insurrance then
        signal sqlstate '45000' set message_text = 'Giá trị của Insurance phải = 10% của BasicSalary';
    end if;
end;

