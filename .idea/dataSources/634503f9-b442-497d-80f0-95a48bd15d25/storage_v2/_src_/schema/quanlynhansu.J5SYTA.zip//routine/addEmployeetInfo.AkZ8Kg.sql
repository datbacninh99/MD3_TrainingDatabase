create
    definer = root@localhost procedure addEmployeetInfo(IN Name_in varchar(150), IN email_IN varchar(150),
                                                        IN phone_IN varchar(50), IN address_IN varchar(255),
                                                        IN gender_IN tinyint, IN birthday_IN date, IN levelId_IN int,
                                                        IN departmentId_IN int)
begin
    insert into employee(Name, email, phone, address, gender, birthday, levelId, departmentId)
        value
        (Name_in, email_IN, phone_IN, address_IN, gender_IN, birthday_IN, levelId_IN, departmentId_IN);
end;

