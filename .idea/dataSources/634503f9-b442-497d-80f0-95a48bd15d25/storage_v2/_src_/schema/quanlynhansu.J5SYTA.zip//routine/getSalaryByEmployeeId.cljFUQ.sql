create
    definer = root@localhost procedure getSalaryByEmployeeId(IN employeeId_IN int)
begin
    select e.Id,
           e.Name EmployeeName,
           Phone,
           Email,
           BasicSalary,
           AllowanceSalary,
           BonusSalary,
           Insurrance,
           sum(value)
                  TotalDay,
           (BasicSalary+BonusSalary+AllowanceSalary-Insurrance)*sum(value)/24 TotalSalary
    from salary s
             join employee e on s.employeeId = e.Id
             join levels l on e.levelId = l.Id
             join timesheets t on e.Id = t.employeeId
    where month(curdate()) = month(AttendanceDate) and year(curdate()) = year(AttendanceDate) and e.Id = employeeId_IN
    group by e.Id,s.BonusSalary,s.Insurrance;
end;

