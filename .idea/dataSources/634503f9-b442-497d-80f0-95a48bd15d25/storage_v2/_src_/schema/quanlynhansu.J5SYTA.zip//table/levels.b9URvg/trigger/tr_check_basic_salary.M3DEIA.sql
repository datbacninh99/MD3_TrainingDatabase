create definer = root@localhost trigger tr_check_basic_salary
    before insert
    on levels
    for each row
begin
    if NEW.BasicSalary > 10000000
    then
        begin
            set NEW.BasicSalary = 10000000;
        end;
    end if;
end;

